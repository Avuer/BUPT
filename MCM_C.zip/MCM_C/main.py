# import openpyxl and decimal
from openpyxl import load_workbook, Workbook
import decimal

# create a new workbook
mybook = Workbook()

letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
num = {'a':0.0788, 'b':0.0156 , 'c':0.0268, 'd':0.0389, 'e':0.1268, 'f':0.0256, 'g':0.0187, 'h':0.0573, 'i':0.0707, 'j':0.0010 , 'k':0.0060 , 'l':0.0394, 'm':0.0244, 'n':0.0706, 'o':0.0776, 'p':0.0186, 'q':0.0009 , 'r':0.0594, 's':0.0634, 't':0.0978, 'u':0.0280, 'v':0.0120, 'w':0.0214, 'x':0.0016, 'y':0.0202, 'z':0.0006}

# Open the Excel file
workbook = load_workbook(filename = "./Data.xlsx")
print(workbook.sheetnames)
sheet = workbook["Sheet1"]
print(sheet)

# get the number of rows and columns
print(sheet.dimensions)

# get the data
list = []
for i in range(3, 357):
    cell = sheet.cell(row = i, column = 3)
    list.append(cell.value)
    
# print(list)
name, rate = [], []

for i in range(354):
    for k in range(26):
        count = list[i].count(f'{letters[k]}', 0, 5)
        if count > 1:       
            name.append(list[i])
            rate.append(count)
            
print(name)
print(rate)

wa = mybook.active
wa.append(name)
wa.append(rate)
mybook.save(filename = "./Rate.xlsx")      


     
# Fill in repeat.xlsx with the repeat times

repeet, name= [], []

for word in list:
    total = 0
    for i in word:
        total += decimal.Decimal(f'{num[i]}')
    name.append(word)
    repeet.append(total)

print(repeat)
print(name)

wa.append(name)
wa.append(repeat)
mybook.save(filename = "./Repeat.xlsx")
