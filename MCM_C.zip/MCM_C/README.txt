<--Here are the instructions for this folder-->
START:

1. Data.xlsx is the raw data that was processed this time, Data2 is the F-test
2. main.py is the source code to process summaries x1 through x7, y1 through y3 created by Data.xlsx and plots code by BP tools
3. Repeat.xlsx is the result of counting the number of repeated letters, Rate.xlsx is the frequency of letters
4. z.mat is consist of z1, z2, z3 which is in Data.xlsx
5. main.m is the matlab source code to solve all questions

END